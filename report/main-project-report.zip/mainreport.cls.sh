#!/bin/sh
mogrify -crop 0x1395+0+0 mainreport.cls.png
exit 0
